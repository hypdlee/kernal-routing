# Stage 4 gates: Tiny-ImageNet at width 64

Closes the last coverage gap. The inverted-U across widths, and the
saturation account of the width-64 null, are currently CIFAR-100 results.
This tests both on a second dataset.

The mechanism makes a clear prediction here. At width 64 on
Tiny-ImageNet the network should be close to memorising the training set,
so the routing effect should shrink toward nothing, as it did on
CIFAR-100 (+1.153pp at w32 falling to +0.080pp at w64). Predicting the
answer before running is the point; recording the prediction is what
makes the test meaningful.

PREDICTION, recorded 2026-09-19 before any run:
  gap - static at w64 on Tiny-ImageNet will be under +0.5pp and
  statistically equivalent to static by TOST. Final training loss of the
  static arm will be below 0.05, against 0.1194 at width 32.
  If either fails, the saturation account is CIFAR-specific.

---

- [ ] S1 probe passes
  CHECK: `python run_tin_w64.py --probe`
  EXPECT: no out-of-memory error; note the epoch time. One gap run is
  that time x150; the whole stage is roughly 87 h.
  WHY: at 64x64 the blend path stacks K outputs at 64x64 in stage 1,
  268 MB per dynamic layer against 67 MB on CIFAR, and autograd holds
  them. Roughly 2 GB of stacked outputs before ordinary activations.
  This is the tightest memory point in the whole program.
  ON FAILURE: drop to --batch-size 64 and halve the learning rate, apply
  it to all three arms, and log in PREREGISTRATION.md that width-64
  Tiny-ImageNet uses a different batch size from width 32, so those two
  widths are not directly comparable on that dataset. The within-width
  three-arm comparison, which is what this stage is for, stays valid.
  EVIDENCE: pending

- [ ] S2 probe artefacts removed
  CHECK: delete results/probe before the real run
  WHY: check_grid walks results/ recursively; a 1-epoch run would show
  up as a failed cell.
  EVIDENCE: pending

- [ ] S3 18 runs complete
  CHECK: `python run_tin_w64.py` then
  `python check_grid.py --dir results --tag tin_w64 --routers static uniform gap --seeds 0 1 2 3 4 5`
  EXPECT: 18/18, AUDIT PASSED. Params: static about 11.3M, uniform about
  44.2M, gap about 44.5M, each slightly above the CIFAR figure because of
  the wider 200-class head.
  NOTE: seed-major order, unlike earlier stages. An interruption leaves
  complete seed triplets that still support a paired analysis at reduced
  n, rather than one finished arm with nothing to pair against.
  EVIDENCE: pending

- [ ] S4 saturation measured
  CHECK: `python analyze_capacity.py --dataset tinyimagenet`
  EXPECT: final training loss reported per arm at both widths. The
  prediction is below 0.05 at w64 against 0.1194 at w32.
  EVIDENCE: pending

- [ ] S5 verdict against the recorded prediction
  EXPECT: quote the prediction above, then the measured gap - static with
  CI, p and TOST. State plainly whether it held. A failure is a result
  and goes in the paper as one.
  EVIDENCE: pending

- [ ] S6 paper updated either way
  The Section 12 limitation "the inverted-U shape across widths remains a
  CIFAR-100 result" is either removed or narrowed, depending on S5. Do
  not leave it stale.
  EVIDENCE: pending

ABANDON lines go here if a gate becomes impossible, with the reason.
