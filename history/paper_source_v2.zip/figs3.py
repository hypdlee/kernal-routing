import sys; sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from data import *
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.25,
                     "axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":200,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
C={"static":"#444444","uniform":"#1f77b4","gap":"#d62728"}
tacc=lambda a: np.array([TIN[a][s]["final_acc"] for s in SEEDS])
tloss=lambda a: np.mean([TIN[a][s]["history"][-1]["loss"] for s in SEEDS])
kacc=lambda k: np.array([KSW[k][s]["final_acc"] for s in SEEDS])

# ---- Fig 7: cross-dataset, and the prediction ---------------------------
fig,ax=plt.subplots(1,3,figsize=(7.6,2.85))

for i,a in enumerate(["static","gap"]):
    v=tacc(a); ax[0].scatter([i]*6,v,s=28,color=C[a],zorder=3,alpha=.85)
    ax[0].hlines(v.mean(),i-.28,i+.28,color="k",lw=1.7,zorder=4)
ax[0].set_xticks([0,1]); ax[0].set_xticklabels(["static","gap"])
ax[0].set_ylabel("top-1 test accuracy (%)")
ax[0].set_title("(a) Tiny-ImageNet, w32",fontsize=9)
d=tacc("gap")-tacc("static")
ax[0].annotate(f"$+{d.mean():.2f}$pp",(0.5,(tacc('static').mean()+tacc('gap').mean())/2),
               ha="center",fontsize=8,bbox=dict(fc="white",ec="none",alpha=.9,pad=1.5))

x=np.arange(2); bw=.34
for j,a in enumerate(["static","gap"]):
    ax[1].bar(x+(j-.5)*bw,[loss(32,a),tloss(a)],bw,color=C[a],label=a)
ax[1].axhline(0.008,color="k",lw=.7,ls="-.")
ax[1].annotate("memorisation floor",(0.0,0.0105),fontsize=6)
ax[1].set_xticks(x); ax[1].set_xticklabels(["CIFAR-100","Tiny-ImageNet"],fontsize=8)
ax[1].set_ylabel("final training loss"); ax[1].legend(frameon=False,fontsize=7.5)
ax[1].set_title("(b) distance from saturation",fontsize=9)

lo=[loss(32,"static"),tloss("static")]
ef=[paired(acc(32,"gap"),acc(32,"static")),paired(tacc("gap"),tacc("static"))]
for i,(lbl,col) in enumerate([("CIFAR-100","#7f7f7f"),("Tiny-ImageNet","#e377c2")]):
    ax[2].errorbar(lo[i],ef[i]["mean"],
        yerr=[[ef[i]["mean"]-ef[i]["lo"]],[ef[i]["hi"]-ef[i]["mean"]]],
        marker="o",ms=6,capsize=4,lw=1.4,color=col,label=lbl)
    ax[2].annotate(lbl,(lo[i],ef[i]["mean"]),xytext=(6,-11),
                   textcoords="offset points",fontsize=7)
ax[2].plot(lo,[e["mean"] for e in ef],ls=":",color="k",lw=1)
ax[2].set_xlabel("final training loss of the static arm")
ax[2].set_ylabel("routing effect (pp)")
ax[2].set_title("(c) effect vs saturation",fontsize=9)
plt.savefig("fig/fig7_crossdataset.pdf"); plt.close()

# ---- Fig 8: K sweep ----------------------------------------------------
fig,ax=plt.subplots(1,2,figsize=(7.4,2.8))
ks=[2,4,8]
e=[paired(kacc(k),acc(32,"static")) for k in ks]
ax[0].errorbar(ks,[q["mean"] for q in e],
    yerr=[[q["mean"]-q["lo"] for q in e],[q["hi"]-q["mean"] for q in e]],
    marker="o",ms=5,capsize=3,lw=1.4,color="#d62728")
ax[0].axhline(0,color="k",lw=.8)
ax[0].set_xscale("log",base=2); ax[0].set_xticks(ks); ax[0].set_xticklabels(ks)
ax[0].set_xlabel("bank size $K$"); ax[0].set_ylabel("$\\Delta$ vs static (pp)")
ax[0].set_ylim(0,1.8); ax[0].set_title("(a) effect is flat in $K$",fontsize=9)

pr=[KSW[k][0]["params"]["total"]/1e6 for k in ks]
mn=[np.mean([KSW[k][s]["minutes"] for s in SEEDS]) for k in ks]
ax2=ax[1].twinx()
ax[1].plot(ks,pr,marker="s",ms=5,color="#1f77b4",label="parameters")
ax2.plot(ks,mn,marker="^",ms=5,color="#2ca02c",ls="--",label="minutes/run")
ax[1].set_xscale("log",base=2); ax[1].set_xticks(ks); ax[1].set_xticklabels(ks)
ax[1].set_xlabel("bank size $K$"); ax[1].set_ylabel("stored parameters (M)",color="#1f77b4")
ax2.set_ylabel("training minutes per run",color="#2ca02c"); ax2.grid(False)
ax[1].set_title("(b) cost is not",fontsize=9)
plt.savefig("fig/fig8_ksweep.pdf"); plt.close()
print("figs 7-8 written")
