r"""Build the report: tables -> substitution -> pdflatex (twice, for refs).

Tables are substituted into the document rather than \input, because
LaTeX's \input inside a tabular breaks the alignment ("Misplaced
\noalign"). Verified: identical rows compile with zero errors inline and
fail via \input.
"""
import pathlib, subprocess, sys, re

src = pathlib.Path("paper_template.tex").read_text()
for tab in sorted(pathlib.Path(".").glob("tab_T*.tex")):
    key = tab.stem.split("_")[1]
    marker = f"%%{key}%%"
    if marker not in src:
        print(f"warning: {marker} not found in template"); continue
    src = src.replace(marker, tab.read_text().rstrip())
left = re.findall(r"%%T\d%%", src)
if left:
    sys.exit(f"unsubstituted markers remain: {left}")
pathlib.Path("paper.tex").write_text(src)

for i in (1, 2):
    r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "paper.tex"],
                       capture_output=True, text=True)
log = pathlib.Path("paper.log").read_text()
errs = [l for l in log.splitlines() if l.startswith("! ")]
warns = [l for l in log.splitlines() if "Warning" in l and "undefined" in l.lower()]
print(f"errors: {len(errs)}   undefined-reference warnings: {len(warns)}")
for e in errs[:10]: print("  ", e)
for w in warns[:5]: print("  ", w)
pdf = pathlib.Path("paper.pdf")
print("PDF:", pdf.stat().st_size, "bytes" if pdf.exists() else "MISSING")
