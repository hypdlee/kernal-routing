import sys; sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from data import *
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.25,
                     "axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":200,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
C={"static":"#444444","uniform":"#1f77b4","gap":"#d62728",
   "shuffled":"#2ca02c","frozen_random":"#9467bd"}

# Train-loss curves, seed 0, sampled every 10 epochs from the run logs.
EP=[0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,149]
CURVE={
 (16,"static"):[4.393,1.808,1.538,1.436,1.365,1.309,1.235,1.150,1.062,0.940,0.812,0.646,0.459,0.282,0.181,0.160],
 (16,"gap")   :[4.395,1.878,1.538,1.423,1.331,1.260,1.173,1.084,0.962,0.846,0.680,0.495,0.290,0.131,0.075,0.065],
 (32,"static"):[4.319,1.586,1.297,1.193,1.110,1.017,0.933,0.820,0.715,0.570,0.413,0.230,0.088,0.028,0.019,0.017],
 (32,"gap")   :[4.319,1.598,1.285,1.165,1.077,1.000,0.907,0.804,0.682,0.530,0.357,0.190,0.059,0.020,0.014,0.013],
 (64,"static"):[4.238,1.450,1.137,1.012,0.924,0.834,0.741,0.627,0.506,0.379,0.222,0.090,0.016,0.009,0.008,0.008],
}
h=R[64]["gap"][0]["history"]
CURVE[(64,"gap")]=[h[e]["loss"] for e in EP]

fig,ax=plt.subplots(1,2,figsize=(7.4,2.9))
ls={16:":",32:"--",64:"-"}
for w in [16,32,64]:
    for a in ["static","gap"]:
        ax[0].plot(EP,CURVE[(w,a)],ls[w],color=C[a],lw=1.3,
                   label=f"{a}, w{w}" if True else None)
ax[0].set_yscale("log"); ax[0].set_xlabel("epoch"); ax[0].set_ylabel("training loss (log)")
ax[0].axhline(0.008,color="k",lw=.7,ls="-.")
ax[0].annotate("memorisation floor",(60,0.0086),fontsize=6)
ax[0].set_title("(a) training loss, seed 0"); ax[0].legend(frameon=False,fontsize=6,ncol=2)

x=np.arange(3); bw=.26
for j,a in enumerate(["static","uniform","gap"]):
    ax[1].bar(x+(j-1)*bw,[loss(w,a) for w in [16,32,64]],bw,color=C[a],label=a)
for i,w in enumerate([16,32,64]):
    ax[1].annotate(f"{loss(w,'static'):.3f}",(x[i]-bw,loss(w,"static")+0.004),
                   fontsize=6,ha="center")
ax[1].set_xticks(x); ax[1].set_xticklabels(["w16","w32","w64"])
ax[1].set_ylabel("final training loss"); ax[1].set_title("(b) saturation by width")
ax[1].legend(frameon=False,fontsize=7.5)
plt.savefig("fig/fig5_saturation.pdf"); plt.close()

# ---- Fig 6: width-64 routing controls + entropy -------------------------
fig,ax=plt.subplots(1,2,figsize=(7.4,2.9))
arms=["static","uniform","gap","shuffled","frozen_random"]
for i,a in enumerate(arms):
    v=acc(64,a); ax[0].scatter([i]*6,v,s=26,color=C[a],zorder=3,alpha=.85)
    ax[0].hlines(v.mean(),i-.3,i+.3,color="k",lw=1.6,zorder=4)
ax[0].axhspan(acc(64,"static").mean()-0.5,acc(64,"static").mean()+0.5,
              color="grey",alpha=0.13)
ax[0].set_xticks(range(5)); ax[0].set_xticklabels(arms,rotation=35,ha="right",fontsize=7)
ax[0].set_ylabel("top-1 test accuracy (%)")
ax[0].set_title("(a) width 64: all five arms",fontsize=9)

for a in ["uniform","gap","shuffled","frozen_random"]:
    by={}
    for s in SEEDS:
        for L in R[64][a][s]["routing"]:
            by.setdefault(L["layer"],[]).append(L["z_entropy_norm"])
    ks=sorted(by); ax[1].plot(ks,[np.mean(by[k]) for k in ks],marker="o",ms=3,
                              lw=1.2,color=C[a],label=a)
ax[1].set_xlabel("dynamic layer index (shallow $\\rightarrow$ deep)")
ax[1].set_ylabel("normalised routing entropy $\\tilde H$")
ax[1].set_ylim(0.90,1.005); ax[1].legend(frameon=False,fontsize=7)
ax[1].set_title("(b) routing entropy, mean over 6 seeds",fontsize=9)
plt.savefig("fig/fig6_w64controls.pdf"); plt.close()
print("figs 5-6 written")
