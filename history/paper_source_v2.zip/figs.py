import sys; sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from data import *

plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.25,
                     "axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":200,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
C = {"static":"#444444","uniform":"#1f77b4","gap":"#d62728",
     "shuffled":"#2ca02c","frozen_random":"#9467bd"}
W = [16,32,64]

# ---- Fig 1: capacity sweep + effect size ---------------------------------
fig,ax = plt.subplots(1,2,figsize=(7.4,2.9))
for a in ["static","uniform","gap"]:
    m=[acc(w,a).mean() for w in W]; s=[acc(w,a).std(ddof=1) for w in W]
    ax[0].errorbar(W,m,yerr=s,marker="o",ms=4,capsize=3,lw=1.4,color=C[a],label=a)
ax[0].set_xscale("log",base=2); ax[0].set_xticks(W); ax[0].set_xticklabels(W)
ax[0].set_xlabel("base width $c$"); ax[0].set_ylabel("top-1 test accuracy (%)")
ax[0].set_title("(a) accuracy vs capacity"); ax[0].legend(frameon=False,fontsize=8)

for a,mk in [("uniform","s"),("gap","o")]:
    e=[paired(acc(w,a),acc(w,"static")) for w in W]
    ax[1].errorbar(W,[x["mean"] for x in e],
        yerr=[[x["mean"]-x["lo"] for x in e],[x["hi"]-x["mean"] for x in e]],
        marker=mk,ms=4,capsize=3,lw=1.4,color=C[a],label=f"{a} - static")
ax[1].axhline(0,color="k",lw=0.8)
ax[1].axhspan(-0.5,0.5,color="grey",alpha=0.13,label="equivalence margin $\\pm0.5$")
ax[1].set_xscale("log",base=2); ax[1].set_xticks(W); ax[1].set_xticklabels(W)
ax[1].set_xlabel("base width $c$"); ax[1].set_ylabel("$\\Delta$ accuracy (pp)")
ax[1].set_title("(b) effect vs static, 95% CI"); ax[1].legend(frameon=False,fontsize=7.5)
plt.savefig("fig/fig1_sweep.pdf"); plt.close()

# ---- Fig 2: every single run -------------------------------------------
fig,axs = plt.subplots(1,3,figsize=(7.4,2.8))
for k,w in enumerate(W):
    arms=["static","uniform","gap"]+(["shuffled","frozen_random"] if w==64 else [])
    for i,a in enumerate(arms):
        v=acc(w,a)
        axs[k].scatter([i]*6,v,s=26,color=C[a],zorder=3,alpha=.85)
        axs[k].hlines(v.mean(),i-.3,i+.3,color="k",lw=1.6,zorder=4)
        for s in SEEDS:
            axs[k].annotate(str(s),(i,v[s]),fontsize=4.5,color="white",
                            ha="center",va="center",zorder=5)
    axs[k].set_xticks(range(len(arms)))
    axs[k].set_xticklabels(arms,rotation=35,ha="right",fontsize=7)
    axs[k].set_title(f"width {w}"); 
    if k==0: axs[k].set_ylabel("top-1 test accuracy (%)")
fig.suptitle("All 66 runs. Point labels are seed indices; bar is the arm mean.",
             fontsize=8,y=1.04)
plt.savefig("fig/fig2_allruns.pdf"); plt.close()

# ---- Fig 3: decomposition ----------------------------------------------
fig,ax=plt.subplots(figsize=(5.2,3.0))
x=np.arange(3); bw=0.36
allhi=[]
for j,(lbl,f,col) in enumerate([
        ("bank  (uniform $-$ static)", lambda w:paired(acc(w,"uniform"),acc(w,"static")),"#1f77b4"),
        ("routing  (gap $-$ uniform)", lambda w:paired(acc(w,"gap"),acc(w,"uniform")),"#d62728")]):
    e=[f(w) for w in W]; allhi+=[q["hi"] for q in e]
    ax.bar(x+(j-0.5)*bw,[q["mean"] for q in e],bw,color=col,label=lbl,
           yerr=[[q["mean"]-q["lo"] for q in e],[q["hi"]-q["mean"] for q in e]],
           capsize=3,error_kw=dict(lw=1))
    for i,q in enumerate(e):
        ax.annotate(("$p{<}10^{-3}$" if q["p"]<1e-3 else f"$p={q['p']:.3f}$"),
                    (x[i]+(j-0.5)*bw,q["hi"]+0.05),ha="center",fontsize=6.2,rotation=90,
                    va="bottom")
ax.axhline(0,color="k",lw=.8); ax.set_xticks(x); ax.set_xticklabels([f"width {w}" for w in W])
ax.set_ylabel("$\\Delta$ accuracy (pp)")
ax.set_ylim(top=max(allhi)+0.62)
ax.legend(frameon=False,fontsize=7.5,loc="lower center",bbox_to_anchor=(0.5,-0.34),ncol=2)
ax.set_title("Contribution of the bank and of routing",fontsize=9)
plt.savefig("fig/fig3_decomp.pdf"); plt.close()

# ---- Fig 4: parameter-matched ------------------------------------------
fig,ax=plt.subplots(figsize=(4.8,3.0))
for a in ["static","uniform","gap"]:
    p=[par(w,a)/1e6 for w in W]; m=[acc(w,a).mean() for w in W]
    ax.plot(p,m,marker="o",ms=4.5,lw=1.4,color=C[a],label=a)
    for w,pp,mm in zip(W,p,m): ax.annotate(f"w{w}",(pp,mm),fontsize=6,
                                           xytext=(3,-8),textcoords="offset points")
for (wg,ws) in [(16,32),(32,64)]:
    xg,yg=par(wg,"gap")/1e6,acc(wg,"gap").mean()
    xs,ys=par(ws,"static")/1e6,acc(ws,"static").mean()
    ax.annotate("",xy=(xs,ys),xytext=(xg,yg),
                arrowprops=dict(arrowstyle="->",color="black",lw=1.1,ls=":"))
    ax.annotate(f"$+{ys-yg:.2f}$pp",((xg+xs)/2,(yg+ys)/2),fontsize=6.5,
                ha="center",bbox=dict(fc="white",ec="none",alpha=.85,pad=1))
ax.set_xscale("log"); ax.set_xlabel("stored parameters (M, log scale)")
ax.set_ylabel("top-1 test accuracy (%)")
ax.set_title("Matched parameter budgets",fontsize=9); ax.legend(frameon=False,fontsize=8)
plt.savefig("fig/fig4_parammatched.pdf"); plt.close()
print("figs 1-4 written")
