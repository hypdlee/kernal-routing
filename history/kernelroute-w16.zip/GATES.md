# Stage 1 gates

## COMPLETE (evidence recorded 2026-09-10)

- [x] G1 scipy installed
  EVIDENCE: analyze.py ran to completion, no ImportError.

- [x] G2 grid complete, 24/24 cells
  EVIDENCE: check_grid.py -> "24/24 cells present", no MISSING line.

- [x] G3 grid uniformly configured
  EVIDENCE: check_grid.py -> "AUDIT PASSED"; epochs=150 batch_size=128
  lr=0.1 weight_decay=0.0005 warmup=5 num_kernels=4 scope=all
  temperature=1.0 identical across all 24 runs.

- [x] G4 analysis produced a verdict
  EVIDENCE: uniform vs gap, mean diff -0.032pp, TOST p=0.0033 -> EQUIVALENT.
  frozen_random vs gap, +0.097pp, TOST p=0.0089 -> EQUIVALENT.
  shuffled vs gap, -0.153pp, TOST p=0.0619 -> INCONCLUSIVE.

- [x] G5 verdict read against the pre-registration
  EVIDENCE: decision table row 2, "not significant + TOST p<0.05 ->
  routing is worth less than 0.5pp, write the null". t-test p=0.7752,
  TOST p=0.0033. Row applies.

- [x] G6 routing entropy recorded for all four arms
  EVIDENCE: uniform 1.0000, gap 0.9885 (min 0.9289), shuffled 0.9996,
  frozen_random 0.9971. 96 layer-observations per arm.

- [x] G7 deviations logged
  EVIDENCE: none required; the run matched the pre-registration exactly.

Ledger: 7 of 7 checked.

---

# Stage 1b gates

## COMPLETE (evidence recorded 2026-09-10)

- [x] S1 static arm complete, 6/6 seeds at --scope none
  EVIDENCE: check_grid.py --tag stage1b -> "6/6 cells present".

- [x] S2 static arm matches the Stage 1 recipe apart from scope
  EVIDENCE: AUDIT PASSED; epochs=150 batch_size=128 lr=0.1
  weight_decay=0.0005 warmup=5 num_kernels=4 temperature=1.0, scope=none.

- [x] S3 static parameter count is 11.22M
  EVIDENCE: params.total = 11220132, dyn_layers = 0, printed on every run.

- [x] S4 comparison against all four Stage 1 arms
  EVIDENCE: static 78.338 +/- 0.284. Paired differences vs static:
  uniform +0.048 (p=0.757), gap +0.080 (p=0.616),
  shuffled -0.073 (p=0.736), frozen_random +0.177 (p=0.187).
  All four EQUIVALENT to static by TOST at +/-0.5pp
  (p = 0.0142, 0.0188, 0.0464, 0.0191).
  Omnibus one-way F(4,25) = 0.954, p = 0.450, eta-sq = 0.132.

- [x] S5 the re-parameterisation reading stated explicitly
  EVIDENCE: uniform does NOT beat static (+0.048pp, p=0.757), so the
  linear over-parameterisation effect is absent too. The K=4 bank buys
  nothing by any of the three mechanisms considered: not routing, not
  representational capacity, not optimisation via re-parameterisation.
  Cost: gap trains 4.57x slower than static for a difference
  indistinguishable from zero.

Ledger: 5 of 5 checked.

# Stage 1c gates (optional, decide deliberately)

- [ ] C1 shuffled resolved
  Currently TOST p=0.0619, just outside. Projected to clear 0.05 at n=7
  (p=0.0464) on the observed sd of 0.459. One extra seed.
  DECISION REQUIRED: extending after an inconclusive pre-registered
  result is legitimate and must be logged in PREREGISTRATION.md with a
  date. Extending after a promising result would be optional stopping.
  This is the former. Log it if you do it.
  EVIDENCE: pending

- [ ] C2 low-capacity replication
  Final train loss is ~0.008 in every arm: the models memorise the
  training set completely. The null may be an artifact of the
  overparameterised regime. Re-run uniform and gap at width 32 or K=2 to
  check the null survives. Two arms, six seeds, cheaper per run.
  EVIDENCE: pending

ABANDON lines go here if a gate becomes impossible, with the reason.

---

# Stage 1c gates (capacity sweep)

## width 32 COMPLETE (evidence recorded 2026-09-10)

- [x] C1 width recorded in every stage1c result
  EVIDENCE: config.width = 32 in all 18 records; run headers read
  "[gap w32 seed=N]".

- [x] C2 parameter counts match the expected sweep
  EVIDENCE: static 2.82M, uniform 11.06M, gap 11.13M. As predicted.

- [x] C3 width 32 complete, 18 runs
  EVIDENCE: check_grid.py --tag stage1c_w32 -> 18/18, AUDIT PASSED.
  (Required a fix to check_grid.py: 'scope' was in CRITICAL and flagged
  the static arm's scope=none as recipe drift. Scope is now checked
  per-arm instead. stage1 and stage1b re-audited, both still pass.)

- [x] C5 trend read from per-width tests
  EVIDENCE: w32 gap - static = +1.153pp, p=0.00003, CI [+0.940, +1.367].
  w64 gap - static = +0.080pp, p=0.616, EQUIVALENT. Decomposition at w32:
  bank alone +0.175pp (p=0.221, equivalent), routing alone +0.978pp
  (p=0.00104). At w64 both components are null.
  Parameter-matched: static@w64 (11.22M) beats gap@w32 (11.13M) by
  +2.313pp, p=0.00004.

- [ ] C4 saturation actually broken at the small widths
  STATUS: NOT MET at w32. Final train loss 0.0170 (static/uniform) and
  0.0132 (gap), against 0.0080 at w64. Lower, but still near-total
  memorisation. The w32 effect is therefore real but was measured inside
  the saturated regime, and the objection is not yet answered.
  EVIDENCE: pending at w16.

## width 16 (open)

- [ ] C6 width 16 complete, 18 runs
  CHECK: `python run_stage1c_capacity.py --widths 16` then
  `python check_grid.py --dir results --tag stage1c_w16 --routers static uniform gap --seeds 0 1 2 3 4 5`
  EXPECT: 18/18, AUDIT PASSED; params static 0.71M, uniform 2.77M, gap 2.79M
  EVIDENCE: pending

- [ ] C7 three-point trend
  CHECK: `python analyze_capacity.py`
  EXPECT: a verdict naming w16 and w64 explicitly
  EVIDENCE: pending

- [ ] C8 saturation broken, or escalate
  EXPECT: final train loss clearly above 0.05 at w16. If it lands near
  0.017 again, w16 has not escaped either and the next step is width 8 or
  a shorter schedule. Decide before writing up, not after.
  EVIDENCE: pending

ABANDON lines go here if a gate becomes impossible, with the reason.
