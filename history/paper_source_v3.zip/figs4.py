import sys; sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, math
from data import *
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.25,
                     "axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":200,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
C={"static":"#444444","uniform":"#1f77b4","gap":"#d62728","ann":"#ff7f0e"}
W=[16,32,64]
aacc=lambda w: np.array([ANN[w][s]["final_acc"] for s in SEEDS])
tacc=lambda a: np.array([TIN[a][s]["final_acc"] for s in SEEDS])

# ---- Fig 9: temperature ablation ---------------------------------------
fig,ax=plt.subplots(1,3,figsize=(7.8,2.85))
x=np.arange(3); bw=.36
ec=[paired(acc(w,"gap"),acc(w,"static")) for w in W]
ea=[paired(aacc(w),acc(w,"static")) for w in W]
for j,(lbl,e,col) in enumerate([("$\\tau=1$ constant",ec,C["gap"]),
                                ("$\\tau:30\\rightarrow1$",ea,C["ann"])]):
    ax[0].bar(x+(j-.5)*bw,[q["mean"] for q in e],bw,color=col,label=lbl,
        yerr=[[q["mean"]-q["lo"] for q in e],[q["hi"]-q["mean"] for q in e]],
        capsize=3,error_kw=dict(lw=1))
ax[0].axhline(0,color="k",lw=.8)
ax[0].axhspan(-0.5,0.5,color="grey",alpha=0.13)
ax[0].set_xticks(x); ax[0].set_xticklabels([f"w{w}" for w in W])
ax[0].set_ylabel("gap $-$ static (pp)"); ax[0].legend(frameon=False,fontsize=7)
ax[0].set_title("(a) effect under both recipes",fontsize=9)

for j,(lbl,f,col) in enumerate([("$\\tau=1$",lambda w:ent(R[w]["gap"]),C["gap"]),
                                ("annealed",lambda w:ent(ANN[w]),C["ann"])]):
    v=[1-f(w).mean() for w in W]
    ax[1].plot(W,v,marker="o",ms=5,lw=1.4,color=col,label=lbl)
ax[1].set_yscale("log"); ax[1].set_xscale("log",base=2)
ax[1].set_xticks(W); ax[1].set_xticklabels(W)
ax[1].set_xlabel("base width $c$"); ax[1].set_ylabel("$1-\\tilde H$  (log)")
ax[1].legend(frameon=False,fontsize=7.5)
ax[1].set_title("(b) router flatness",fontsize=9)

for j,(lbl,af,col) in enumerate([("$\\tau=1$",lambda w:acc(w,"gap"),C["gap"]),
                                 ("annealed",aacc,C["ann"])]):
    xs=[1-(ent(R[w]["gap"]) if j==0 else ent(ANN[w])).mean() for w in W]
    ys=[(af(w)-acc(w,"uniform")).mean() for w in W]
    ax[2].scatter(xs,ys,s=42,color=col,label=lbl,zorder=3)
    for w,xx,yy in zip(W,xs,ys):
        ax[2].annotate(f"w{w}",(xx,yy),xytext=(5,-9),textcoords="offset points",fontsize=6.5)
ax[2].axhline(0,color="k",lw=.8); ax[2].set_xscale("log")
ax[2].set_xlabel("$1-\\tilde H$  (log)"); ax[2].set_ylabel("gap $-$ uniform (pp)")
ax[2].legend(frameon=False,fontsize=7.5)
ax[2].set_title("(c) flatness does not predict benefit",fontsize=9)
plt.savefig("fig/fig9_temperature.pdf"); plt.close()

# ---- Fig 10: the entropy counterexample --------------------------------
fig,ax=plt.subplots(1,2,figsize=(7.2,2.9))
labels=["constant\n$\\tau=1$","annealed\n$\\tau:30\\to1$"]
ents=[1-ent(R[16]["gap"]).mean(), 1-ent(ANN[16]).mean()]
bens=[(acc(16,"gap")-acc(16,"uniform")).mean(), (aacc(16)-acc(16,"uniform")).mean()]
b=ax[0].bar(labels,ents,color=[C["gap"],C["ann"]],width=.55)
ax[0].set_yscale("log"); ax[0].set_ylabel("$1-\\tilde H$  (log, lower = flatter)")
for r,v in zip(b,ents): ax[0].annotate(f"{v:.5f}",(r.get_x()+r.get_width()/2,v*1.15),
                                       ha="center",fontsize=7)
ax[0].set_title("(a) width 16: router flatness",fontsize=9)
ax[0].annotate("14x flatter",(0.5,0.012),ha="center",fontsize=8,
               bbox=dict(fc="white",ec="none",alpha=.9))

b=ax[1].bar(labels,bens,color=[C["gap"],C["ann"]],width=.55)
for r,v in zip(b,bens): ax[1].annotate(f"+{v:.3f}pp",(r.get_x()+r.get_width()/2,v+0.03),
                                       ha="center",fontsize=7.5)
ax[1].set_ylabel("gap $-$ uniform (pp)"); ax[1].set_ylim(0,1.15)
ax[1].set_title("(b) width 16: benefit over uniform",fontsize=9)
fig.suptitle("The flatter router delivered the larger benefit.",fontsize=8.5,y=1.03)
plt.savefig("fig/fig10_counterexample.pdf"); plt.close()

# ---- Fig 11: decomposition, both datasets ------------------------------
fig,ax=plt.subplots(figsize=(5.0,2.9))
x=np.arange(2); bw=.36
sets=[("CIFAR-100",acc(32,"static"),acc(32,"uniform"),acc(32,"gap")),
      ("Tiny-ImageNet",tacc("static"),tacc("uniform"),tacc("gap"))]
for j,(lbl,f,col) in enumerate([("bank (uniform $-$ static)",lambda s:paired(s[2],s[1]),"#1f77b4"),
                                ("routing (gap $-$ uniform)",lambda s:paired(s[3],s[2]),"#d62728")]):
    e=[f(s) for s in sets]
    ax.bar(x+(j-.5)*bw,[q["mean"] for q in e],bw,color=col,label=lbl,
        yerr=[[q["mean"]-q["lo"] for q in e],[q["hi"]-q["mean"] for q in e]],
        capsize=3,error_kw=dict(lw=1))
    for i,q in enumerate(e):
        ax.annotate("$p<10^{-3}$" if q["p"]<1e-3 else f"$p={q['p']:.2f}$",
                    (x[i]+(j-.5)*bw,q["hi"]+0.07),ha="center",fontsize=6.5,rotation=90,va="bottom")
ax.axhline(0,color="k",lw=.8); ax.set_xticks(x)
ax.set_xticklabels([s[0] for s in sets]); ax.set_ylim(-0.4,3.2)
ax.set_ylabel("$\\Delta$ accuracy (pp)")
ax.legend(frameon=False,fontsize=7.5,loc="upper left")
ax.set_title("Decomposition at width 32, both datasets",fontsize=9)
plt.savefig("fig/fig11_decomp_both.pdf"); plt.close()
print("figs 9-11 written")
