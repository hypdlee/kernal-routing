"""Single source of truth. Every number in the paper comes from here."""
import glob, json, math
import numpy as np
from scipy import stats

def load(resdir="/home/claude/resin/results"):
    """Key on (dataset, width, K, arm). Any coarser key merges runs that
    differ in one of those and the last file read wins."""
    R = {}
    for f in glob.glob(f"{resdir}/*.json"):
        d = json.load(open(f))
        if "router" not in d or "config" not in d:
            continue
        c = d["config"]
        ds = c.get("dataset", "cifar100")
        w = c.get("width", 64)
        k = c.get("num_kernels", 4)
        tau = c.get("temp_start") is not None       # annealed recipe or not
        arm = "static" if c.get("scope") == "none" else d["router"]
        R.setdefault((ds, w, k, tau), {}).setdefault(arm, {})[d["seed"]] = d
    return R

ALL = load()
# Main sweep: CIFAR-100 at K=4, keyed by width for backward compatibility.
R = {w: ALL[("cifar100", w, 4, False)] for w in (16, 32, 64)}
TIN = ALL[("tinyimagenet", 32, 4, False)]
KSW = {k: ALL[("cifar100", 32, k, False)]["gap"] for k in (2, 4, 8)}
ANN = {w: ALL[("cifar100", w, 4, True)]["gap"] for w in (16, 32, 64)}

def ent(recs):
    """Mean normalised routing entropy per seed."""
    return np.array([np.mean([L["z_entropy_norm"] for L in recs[s]["routing"]])
                     for s in sorted(recs)])
SEEDS = list(range(6))
def acc(w, a):   return np.array([R[w][a][s]["final_acc"] for s in SEEDS])
def best(w, a):  return np.array([R[w][a][s]["best_acc"] for s in SEEDS])
def mins(w, a):  return np.array([R[w][a][s]["minutes"] for s in SEEDS])
def par(w, a):   return R[w][a][0]["params"]["total"]
def rpar(w, a):  return R[w][a][0]["params"].get("router", 0)
def loss(w, a):  return np.mean([R[w][a][s]["history"][-1]["loss"] for s in SEEDS])

def paired(x, y, margin=0.5):
    d = x - y; n = len(d); sd = d.std(ddof=1)
    t, p = stats.ttest_rel(x, y)
    se = sd / math.sqrt(n); crit = stats.t.ppf(0.975, n - 1)
    try:
        w_p = stats.wilcoxon(x, y).pvalue
    except ValueError:
        w_p = float("nan")
    pl = stats.t.sf((d.mean() + margin) / se, n - 1)
    pu = stats.t.cdf((d.mean() - margin) / se, n - 1)
    return dict(mean=d.mean(), sd=sd, lo=d.mean() - crit * se, hi=d.mean() + crit * se,
                t=float(t), p=float(p), wilcoxon=float(w_p),
                dz=d.mean() / sd, tost=float(max(pl, pu)))
