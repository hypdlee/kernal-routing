import sys; sys.path.insert(0,'.')
import numpy as np
from data import *

def f(x,n=3): return f"{x:.{n}f}"
def sg(x,n=3): return f"{x:+.{n}f}"
def pv(p):
    if np.isnan(p): return "--"
    return "$<10^{-4}$" if p<1e-4 else f"{p:.4f}"

out={}

# T1: every run
rows=[]
for w in [16,32,64]:
    for a in ["static","uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        v=acc(w,a)
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & " +
                    " & ".join(f(x,2) for x in v) +
                    f" & {f(v.mean(),3)} & {f(v.std(ddof=1),3)} \\\\")
out["T1"]="\n".join(rows)

# T2: configuration
rows=[]
for w in [16,32,64]:
    for a in ["static","uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & {par(w,a):,} & "
                    f"{rpar(w,a):,} & {f(loss(w,a),4)} & {f(mins(w,a).mean(),1)} \\\\")
out["T2"]="\n".join(rows).replace(",","{,}")

# T3: vs static
rows=[]
for w in [16,32,64]:
    for a in ["uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        q=paired(acc(w,a),acc(w,"static"))
        verdict = "equivalent" if q["tost"]<0.05 and q["p"]>=0.05 else (
                  "\\textbf{beats}" if q["p"]<0.05 and q["mean"]>0 else "inconclusive")
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & {sg(q['mean'])} & "
                    f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} & {pv(q['wilcoxon'])} & "
                    f"{sg(q['dz'],2)} & {pv(q['tost'])} & {verdict} \\\\")
out["T3"]="\n".join(rows)

# T4: decomposition
rows=[]
for w in [16,32,64]:
    b=paired(acc(w,"uniform"),acc(w,"static"))
    r=paired(acc(w,"gap"),acc(w,"uniform"))
    t=paired(acc(w,"gap"),acc(w,"static"))
    rows.append(f"{w} & {sg(b['mean'])} & {pv(b['p'])} & {sg(r['mean'])} & {pv(r['p'])} & "
                f"{sg(t['mean'])} & {pv(t['p'])} \\\\")
out["T4"]="\n".join(rows)

# T5: parameter matched
rows=[]
for wg,ws in [(16,32),(32,64)]:
    q=paired(acc(ws,"static"),acc(wg,"gap"))
    rows.append(f"\\texttt{{gap}} @ w{wg} ({par(wg,'gap')/1e6:.2f}M) vs \\texttt{{static}} @ w{ws} "
                f"({par(ws,'static')/1e6:.2f}M) & {f(acc(wg,'gap').mean())} & "
                f"{f(acc(ws,'static').mean())} & {sg(q['mean'])} & "
                f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} \\\\")
out["T5"]="\n".join(rows)

# T6: entropy
rows=[]
for a in ["uniform","gap","shuffled","frozen_random"]:
    e=np.array([L["z_entropy_norm"] for s in SEEDS for L in R[64][a][s]["routing"]])
    sp=np.array([max(L["z_mean"])-min(L["z_mean"]) for s in SEEDS for L in R[64][a][s]["routing"]])
    rows.append(f"\\texttt{{{a.replace('_',chr(92)+'_')}}} & {f(e.mean(),4)} & {f(e.min(),4)} & "
                f"{f(sp.mean(),4)} & {f(sp.max(),4)} & {len(e)} \\\\")
out["T6"]="\n".join(rows)

for k,v in list(out.items()):
    open(f"tab_{k}.tex","w").write(v+"\n")
    print(f"tab_{k}.tex  ({len(v.splitlines())} rows)")

# --- added: cross-dataset and K sweep ----------------------------------
import math
import re as _re
tacc = lambda a: np.array([TIN[a][s]["final_acc"] for s in SEEDS])
tmin = lambda a: np.mean([TIN[a][s]["minutes"] for s in SEEDS])
tloss = lambda a: np.mean([TIN[a][s]["history"][-1]["loss"] for s in SEEDS])
kacc = lambda k: np.array([KSW[k][s]["final_acc"] for s in SEEDS])

# T7: every Tiny-ImageNet run
rows=[]
for a in ["static","gap"]:
    v=tacc(a)
    rows.append(f"\\texttt{{{a}}} & " + " & ".join(f(x,2) for x in v) +
                f" & {f(v.mean(),3)} & {f(v.std(ddof=1),3)} \\\\")
out["T7"]="\n".join(rows)

# T8: cross-dataset side by side
rows=[]
for name,ga,sa,gl,sl,gm,sm in [
    ("CIFAR-100", acc(32,"gap"), acc(32,"static"), loss(32,"gap"), loss(32,"static"),
     mins(32,"gap").mean(), mins(32,"static").mean()),
    ("Tiny-ImageNet", tacc("gap"), tacc("static"), tloss("gap"), tloss("static"),
     tmin("gap"), tmin("static"))]:
    q=paired(ga,sa)
    rows.append(f"{name} & {f(sa.mean())} & {f(ga.mean())} & {sg(q['mean'])} & "
                f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} & {f(sl,4)} & "
                f"{f(sm,1)} / {f(gm,1)} \\\\")
out["T8"]="\n".join(rows)

# T9: K sweep
rows=[]
for k in [2,4,8]:
    v=kacc(k); q=paired(v,acc(32,"static"))
    pr=KSW[k][0]["params"]["total"]/1e6
    mn=np.mean([KSW[k][s]["minutes"] for s in SEEDS])
    rows.append(f"{k} & {f(v.mean())} & {f(v.std(ddof=1),3)} & {sg(q['mean'])} & "
                f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} & {f(pr,2)} & {f(mn,1)} \\\\")
rows.append(f"\\midrule static & {f(acc(32,'static').mean())} & "
            f"{f(acc(32,'static').std(ddof=1),3)} & -- & -- & -- & "
            f"{f(par(32,'static')/1e6,2)} & {f(mins(32,'static').mean(),1)} \\\\")
out["T9"]="\n".join(rows)

# T10: pairwise between K
rows=[]
for a,b in [(2,4),(4,8),(2,8)]:
    q=paired(kacc(b),kacc(a))
    verdict = "equivalent" if q["tost"]<0.05 and q["p"]>=0.05 else "differs"
    rows.append(f"$K={b}$ vs $K={a}$ & {sg(q['mean'])} & [{sg(q['lo'])}, {sg(q['hi'])}] & "
                f"{pv(q['p'])} & {pv(q['tost'])} & {verdict} \\\\")
out["T10"]="\n".join(rows)

for k in ["T7","T8","T9","T10"]:
    # Keep the trailing "\\\\": booktabs \\bottomrule must follow a row
    # separator or LaTeX reports "Misplaced \\noalign".
    open(f"tab_{k}.tex","w").write(out[k].rstrip()+"\n")
    print(f"tab_{k}.tex  ({len(out[k].splitlines())} rows)")

# --- added: Stage 3 -----------------------------------------------------
aacc = lambda w: np.array([ANN[w][s]["final_acc"] for s in SEEDS])
aloss = lambda w: np.mean([ANN[w][s]["history"][-1]["loss"] for s in SEEDS])
tuacc = lambda a: np.array([TIN[a][s]["final_acc"] for s in SEEDS])

# T11: decomposition on both datasets
rows=[]
for nm,st,un,gp in [("CIFAR-100",acc(32,"static"),acc(32,"uniform"),acc(32,"gap")),
                    ("Tiny-ImageNet",tuacc("static"),tuacc("uniform"),tuacc("gap"))]:
    b=paired(un,st); r=paired(gp,un); tt=paired(gp,st)
    share=(gp.mean()-un.mean())/(gp.mean()-st.mean())*100
    rows.append(f"{nm} & {sg(b['mean'])} & {pv(b['p'])} & {pv(b['tost'])} & "
                f"{sg(r['mean'])} & {pv(r['p'])} & {sg(tt['mean'])} & {f(share,1)}\\% \\\\")
out["T11"]="\n".join(rows)

# T12: every Tiny-ImageNet run, now three arms
rows=[]
for a in ["static","uniform","gap"]:
    v=tuacc(a)
    rows.append(f"\\texttt{{{a}}} & " + " & ".join(f(x,2) for x in v) +
                f" & {f(v.mean(),3)} & {f(v.std(ddof=1),3)} \\\\")
out["T12"]="\n".join(rows)

# T13: temperature ablation
rows=[]
for w in [16,32,64]:
    c=acc(w,"gap"); a=aacc(w)
    vs_c=paired(a,c); vs_s=paired(a,acc(w,"static")); vs_u=paired(a,acc(w,"uniform"))
    con_s=paired(c,acc(w,"static"))
    rows.append(f"{w} & {f(c.mean())} & {f(a.mean())} & {sg(vs_c['mean'])} & {pv(vs_c['p'])} & "
                f"{sg(con_s['mean'])} & {sg(vs_s['mean'])} & {sg(vs_u['mean'])} & {pv(vs_u['p'])} \\\\")
out["T13"]="\n".join(rows)

# T14: entropy and benefit, all six conditions
rows=[]
for w in [16,32,64]:
    for lbl,e,a in [("$\\tau=1$",ent(R[w]["gap"]),acc(w,"gap")),
                    ("$30\\!\\to\\!1$",ent(ANN[w]),aacc(w))]:
        q=paired(a,acc(w,"uniform"))
        rms=math.sqrt((1-e.mean())/(4/(2*math.log(4)))/4)
        rows.append(f"{w} & {lbl} & {f(e.mean(),5)} & {f(1-e.mean(),5)} & {f(rms,4)} & "
                    f"{sg(q['mean'])} & {pv(q['p'])} \\\\")
out["T14"]="\n".join(rows)

for k in ["T11","T12","T13","T14"]:
    open(f"tab_{k}.tex","w").write(out[k].rstrip()+"\n")
    print(f"tab_{k}.tex  ({len(out[k].splitlines())} rows)")
