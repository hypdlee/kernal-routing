"""CIFAR-100 loaders. Standard recipe, deliberately boring."""

from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms

MEAN = (0.5071, 0.4865, 0.4409)
STD = (0.2673, 0.2564, 0.2762)


class FakeCIFAR(Dataset):
    """Random tensors with the right shapes, for smoke tests without a
    download. Accuracy on this is meaningless by construction."""

    def __init__(self, n=512, num_classes=100):
        g = torch.Generator().manual_seed(0)
        self.x = torch.randn(n, 3, 32, 32, generator=g)
        self.y = torch.randint(0, num_classes, (n,), generator=g)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.x[i], self.y[i]


def build_loaders(root="./data", batch_size=128, workers=4, fake=False, download=True):
    if fake:
        train_ds, test_ds = FakeCIFAR(512), FakeCIFAR(256)
        workers = 0
    else:
        train_tf = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(MEAN, STD),
        ])
        test_tf = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(MEAN, STD),
        ])
        train_ds = datasets.CIFAR100(root, train=True, download=download, transform=train_tf)
        test_ds = datasets.CIFAR100(root, train=False, download=download, transform=test_tf)

    common = dict(num_workers=workers, pin_memory=not fake, persistent_workers=workers > 0)
    train_ld = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True, **common)
    test_ld = DataLoader(test_ds, batch_size=max(batch_size, 256), shuffle=False, **common)
    return train_ld, test_ld
