# Stage 1 gates

## COMPLETE (evidence recorded 2026-09-10)

- [x] G1 scipy installed
  EVIDENCE: analyze.py ran to completion, no ImportError.

- [x] G2 grid complete, 24/24 cells
  EVIDENCE: check_grid.py -> "24/24 cells present", no MISSING line.

- [x] G3 grid uniformly configured
  EVIDENCE: check_grid.py -> "AUDIT PASSED"; epochs=150 batch_size=128
  lr=0.1 weight_decay=0.0005 warmup=5 num_kernels=4 scope=all
  temperature=1.0 identical across all 24 runs.

- [x] G4 analysis produced a verdict
  EVIDENCE: uniform vs gap, mean diff -0.032pp, TOST p=0.0033 -> EQUIVALENT.
  frozen_random vs gap, +0.097pp, TOST p=0.0089 -> EQUIVALENT.
  shuffled vs gap, -0.153pp, TOST p=0.0619 -> INCONCLUSIVE.

- [x] G5 verdict read against the pre-registration
  EVIDENCE: decision table row 2, "not significant + TOST p<0.05 ->
  routing is worth less than 0.5pp, write the null". t-test p=0.7752,
  TOST p=0.0033. Row applies.

- [x] G6 routing entropy recorded for all four arms
  EVIDENCE: uniform 1.0000, gap 0.9885 (min 0.9289), shuffled 0.9996,
  frozen_random 0.9971. 96 layer-observations per arm.

- [x] G7 deviations logged
  EVIDENCE: none required; the run matched the pre-registration exactly.

Ledger: 7 of 7 checked.

---

# Stage 1b gates

## COMPLETE (evidence recorded 2026-09-10)

- [x] S1 static arm complete, 6/6 seeds at --scope none
  EVIDENCE: check_grid.py --tag stage1b -> "6/6 cells present".

- [x] S2 static arm matches the Stage 1 recipe apart from scope
  EVIDENCE: AUDIT PASSED; epochs=150 batch_size=128 lr=0.1
  weight_decay=0.0005 warmup=5 num_kernels=4 temperature=1.0, scope=none.

- [x] S3 static parameter count is 11.22M
  EVIDENCE: params.total = 11220132, dyn_layers = 0, printed on every run.

- [x] S4 comparison against all four Stage 1 arms
  EVIDENCE: static 78.338 +/- 0.284. Paired differences vs static:
  uniform +0.048 (p=0.757), gap +0.080 (p=0.616),
  shuffled -0.073 (p=0.736), frozen_random +0.177 (p=0.187).
  All four EQUIVALENT to static by TOST at +/-0.5pp
  (p = 0.0142, 0.0188, 0.0464, 0.0191).
  Omnibus one-way F(4,25) = 0.954, p = 0.450, eta-sq = 0.132.

- [x] S5 the re-parameterisation reading stated explicitly
  EVIDENCE: uniform does NOT beat static (+0.048pp, p=0.757), so the
  linear over-parameterisation effect is absent too. The K=4 bank buys
  nothing by any of the three mechanisms considered: not routing, not
  representational capacity, not optimisation via re-parameterisation.
  Cost: gap trains 4.57x slower than static for a difference
  indistinguishable from zero.

Ledger: 5 of 5 checked.

# Stage 1c gates (optional, decide deliberately)

- [ ] C1 shuffled resolved
  Currently TOST p=0.0619, just outside. Projected to clear 0.05 at n=7
  (p=0.0464) on the observed sd of 0.459. One extra seed.
  DECISION REQUIRED: extending after an inconclusive pre-registered
  result is legitimate and must be logged in PREREGISTRATION.md with a
  date. Extending after a promising result would be optional stopping.
  This is the former. Log it if you do it.
  EVIDENCE: pending

- [ ] C2 low-capacity replication
  Final train loss is ~0.008 in every arm: the models memorise the
  training set completely. The null may be an artifact of the
  overparameterised regime. Re-run uniform and gap at width 32 or K=2 to
  check the null survives. Two arms, six seeds, cheaper per run.
  EVIDENCE: pending

ABANDON lines go here if a gate becomes impossible, with the reason.

---

# Stage 1c gates (capacity sweep)

Answers the saturation objection: every width-64 arm finished at a train
loss near 0.008, so the null may belong to the regime rather than to
dynamic convolution.

Three arms (static, uniform, gap) at widths 16 and 32, six seeds each.
Combined with the width-64 results already in hand, that is a three-point
sweep. shuffled and frozen_random are not repeated: they did their job at
width 64, which was to locate which component of routing was inert.

- [ ] C1 width recorded in every stage1c result
  CHECK: read config.width in any stage1c JSON
  EXPECT: 16 or 32, matching the tag
  WHY: --width was added to train.py for this stage. If it reads 64 the
  flag did not take effect and the sweep is void.
  EVIDENCE: pending

- [ ] C2 parameter counts match the expected sweep
  EXPECT: w16 static 0.71M, uniform 2.77M, gap 2.79M
          w32 static 2.82M, uniform 11.06M, gap 11.13M
  EVIDENCE: pending

- [ ] C3 both widths complete, 18 runs each
  CHECK: `python check_grid.py --dir results --tag stage1c_w32 --routers static uniform gap --seeds 0 1 2 3 4 5`
  then the same for stage1c_w16
  EXPECT: 18/18 cells present, AUDIT PASSED
  EVIDENCE: pending

- [ ] C4 saturation actually broken at the small widths
  CHECK: final train loss per width, printed by analyze_capacity.py
  EXPECT: clearly above 0.008 at w16. If w16 also lands at 0.008 the
  replication has not escaped the saturated regime and the objection
  stands unanswered.
  EVIDENCE: pending

- [ ] C5 trend read from the per-width tests, not the correlation
  CHECK: `python analyze_capacity.py`
  EXPECT: a verdict naming the smallest and largest width explicitly. The
  Pearson r across three widths has df=1 and no p-value is reported for
  it by design; the per-width paired tests carry the claim.
  EVIDENCE: pending

Accidental control worth reporting either way: gap at width 32 stores
11.13M parameters and static at width 64 stores 11.22M, matched to within
one percent. A direct comparison of those two is a parameter-matched test
across the whole design.

ABANDON lines go here if a gate becomes impossible, with the reason.
