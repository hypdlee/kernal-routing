"""
Read the capacity sweep: does the dynamic-convolution advantage over a
plain ResNet-18 depend on width?

Pulls width 64 from the existing stage1 / stage1b results and widths 16
and 32 from stage1c. Reports, per width, each arm's accuracy, the paired
difference against static, and whether the models were still saturating.
"""

from __future__ import annotations

import glob
import json
import math

import numpy as np
from scipy import stats

ARMS = ["static", "uniform", "gap"]


def load_all():
    out = {}
    for f in glob.glob("results/*.json"):
        try:
            d = json.load(open(f))
        except Exception:
            continue
        cfg = d.get("config", {})
        if "final_acc" not in d:
            continue
        w = cfg.get("width", 64)
        arm = "static" if cfg.get("scope") == "none" else d["router"]
        if arm not in ARMS:
            continue
        out.setdefault(w, {}).setdefault(arm, {})[d["seed"]] = d
    return out


def tost(d, margin=0.5):
    n = len(d)
    if n < 2:
        return float("nan")
    se = d.std(ddof=1) / math.sqrt(n)
    if se == 0:
        return float("nan")
    return max(stats.t.sf((d.mean() + margin) / se, n - 1),
               stats.t.cdf((d.mean() - margin) / se, n - 1))


def main():
    data = load_all()
    if not data:
        raise SystemExit("no results found under results/")

    print("\n" + "=" * 74)
    print("CAPACITY SWEEP: dynamic convolution vs plain ResNet-18")
    print("=" * 74)

    trend = {}
    for w in sorted(data):
        arms = data[w]
        have = [a for a in ARMS if a in arms and len(arms[a]) >= 2]
        if "static" not in have:
            print(f"\nwidth {w}: no static arm, skipping")
            continue

        print(f"\n--- width {w} " + "-" * 58)
        acc = {a: np.array([arms[a][s]["final_acc"] for s in sorted(arms[a])]) for a in have}
        seedsets = {a: sorted(arms[a]) for a in have}

        for a in have:
            v = acc[a]
            p = arms[a][seedsets[a][0]]["params"]["total"] / 1e6
            loss = np.mean([arms[a][s]["history"][-1]["loss"] for s in seedsets[a]
                            if arms[a][s].get("history")])
            print(f"  {a:<9} n={len(v)}  {v.mean():6.3f} +/- {v.std(ddof=1):.3f}   "
                  f"{p:6.2f}M   final train loss {loss:.4f}")

        print()
        for a in have:
            if a == "static":
                continue
            common = sorted(set(seedsets[a]) & set(seedsets["static"]))
            if len(common) < 2:
                continue
            x = np.array([arms[a][s]["final_acc"] for s in common])
            y = np.array([arms["static"][s]["final_acc"] for s in common])
            d = x - y
            n = len(d)
            t, p = stats.ttest_rel(x, y)
            se = d.std(ddof=1) / math.sqrt(n)
            crit = stats.t.ppf(0.975, n - 1)
            pt = tost(d)
            verdict = "EQUIVALENT to static" if pt < 0.05 else (
                "BEATS static" if p < 0.05 and d.mean() > 0 else "inconclusive")
            print(f"  {a} - static: {d.mean():+6.3f}pp  "
                  f"95% CI [{d.mean()-crit*se:+.3f}, {d.mean()+crit*se:+.3f}]  "
                  f"p={p:.4f}  TOST={pt:.4f}  -> {verdict}")
            trend.setdefault(a, []).append((w, d.mean(), p, pt))

    print("\n" + "=" * 74)
    print("TREND: does the advantage grow as capacity shrinks?")
    print("=" * 74)
    for a, pts in trend.items():
        pts.sort()
        print(f"\n  {a} minus static, by width:")
        for w, m, p, pt in pts:
            bar = ("+" if m >= 0 else "-") * min(40, int(abs(m) * 20))
            print(f"    w{w:<3} {m:+6.3f}pp  p={p:.4f}  {bar}")
        if len(pts) < 3:
            print(f"    only {len(pts)} width(s) present; run the rest before reading a trend.")
            continue

        ws = np.array([np.log2(q[0]) for q in pts])
        ms = np.array([q[1] for q in pts])
        r = stats.pearsonr(ws, ms)[0]
        # A correlation across three widths has one degree of freedom and
        # essentially no power, so its p-value is not reported: it would
        # call a near-perfect monotone trend "not significant" and that
        # would be the same error as reading a Wilcoxon p at n=3. The
        # per-width tests below carry the claim instead; each of those has
        # six paired seeds behind it.
        print(f"    Pearson r with log2(width) = {r:+.3f} "
              f"(3 points, df=1; no p-value reported, see note in source)")

        smallest, largest = pts[0], pts[-1]
        small_wins = smallest[2] < 0.05 and smallest[1] > 0
        large_equiv = (not math.isnan(largest[3])) and largest[3] < 0.05
        if small_wins and large_equiv:
            print(f"    -> at w{smallest[0]} the advantage is real ({smallest[1]:+.3f}pp, "
                  f"p={smallest[2]:.4f}) and at w{largest[0]} it is gone.")
            print("       The width-64 null is a saturation effect. That is the finding,")
            print("       and it explains why the published gains exist.")
        elif all(q[3] < 0.05 for q in pts if not math.isnan(q[3])):
            print("    -> equivalent to static at every width tested. The null holds")
            print("       across capacity, which is the strongest form of the claim.")
        else:
            print("    -> mixed. Read the per-width rows above; no single summary fits.")

    print("\nSaturation check: a final train loss near 0.008 means the model")
    print("memorised the training set. A width where that no longer happens is")
    print("the one that answers the reviewer's objection.\n")


if __name__ == "__main__":
    main()
