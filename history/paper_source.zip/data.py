"""Single source of truth. Every number in the paper comes from here."""
import glob, json, math
import numpy as np
from scipy import stats

def load(resdir="/home/claude/resin/results"):
    R = {}
    for f in glob.glob(f"{resdir}/*.json"):
        d = json.load(open(f))
        if "router" not in d or "config" not in d:
            continue
        c = d["config"]
        w = c.get("width", 64)
        arm = "static" if c.get("scope") == "none" else d["router"]
        R.setdefault(w, {}).setdefault(arm, {})[d["seed"]] = d
    return R

R = load()
SEEDS = list(range(6))
def acc(w, a):   return np.array([R[w][a][s]["final_acc"] for s in SEEDS])
def best(w, a):  return np.array([R[w][a][s]["best_acc"] for s in SEEDS])
def mins(w, a):  return np.array([R[w][a][s]["minutes"] for s in SEEDS])
def par(w, a):   return R[w][a][0]["params"]["total"]
def rpar(w, a):  return R[w][a][0]["params"].get("router", 0)
def loss(w, a):  return np.mean([R[w][a][s]["history"][-1]["loss"] for s in SEEDS])

def paired(x, y, margin=0.5):
    d = x - y; n = len(d); sd = d.std(ddof=1)
    t, p = stats.ttest_rel(x, y)
    se = sd / math.sqrt(n); crit = stats.t.ppf(0.975, n - 1)
    try:
        w_p = stats.wilcoxon(x, y).pvalue
    except ValueError:
        w_p = float("nan")
    pl = stats.t.sf((d.mean() + margin) / se, n - 1)
    pu = stats.t.cdf((d.mean() - margin) / se, n - 1)
    return dict(mean=d.mean(), sd=sd, lo=d.mean() - crit * se, hi=d.mean() + crit * se,
                t=float(t), p=float(p), wilcoxon=float(w_p),
                dz=d.mean() / sd, tost=float(max(pl, pu)))
