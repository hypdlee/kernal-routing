import sys; sys.path.insert(0,'.')
import numpy as np
from data import *

def f(x,n=3): return f"{x:.{n}f}"
def sg(x,n=3): return f"{x:+.{n}f}"
def pv(p):
    if np.isnan(p): return "--"
    return "$<10^{-4}$" if p<1e-4 else f"{p:.4f}"

out={}

# T1: every run
rows=[]
for w in [16,32,64]:
    for a in ["static","uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        v=acc(w,a)
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & " +
                    " & ".join(f(x,2) for x in v) +
                    f" & {f(v.mean(),3)} & {f(v.std(ddof=1),3)} \\\\")
out["T1"]="\n".join(rows)

# T2: configuration
rows=[]
for w in [16,32,64]:
    for a in ["static","uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & {par(w,a):,} & "
                    f"{rpar(w,a):,} & {f(loss(w,a),4)} & {f(mins(w,a).mean(),1)} \\\\")
out["T2"]="\n".join(rows).replace(",","{,}")

# T3: vs static
rows=[]
for w in [16,32,64]:
    for a in ["uniform","gap","shuffled","frozen_random"]:
        if a not in R[w]: continue
        q=paired(acc(w,a),acc(w,"static"))
        verdict = "equivalent" if q["tost"]<0.05 and q["p"]>=0.05 else (
                  "\\textbf{beats}" if q["p"]<0.05 and q["mean"]>0 else "inconclusive")
        rows.append(f"{w} & \\texttt{{{a.replace('_',chr(92)+'_')}}} & {sg(q['mean'])} & "
                    f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} & {pv(q['wilcoxon'])} & "
                    f"{sg(q['dz'],2)} & {pv(q['tost'])} & {verdict} \\\\")
out["T3"]="\n".join(rows)

# T4: decomposition
rows=[]
for w in [16,32,64]:
    b=paired(acc(w,"uniform"),acc(w,"static"))
    r=paired(acc(w,"gap"),acc(w,"uniform"))
    t=paired(acc(w,"gap"),acc(w,"static"))
    rows.append(f"{w} & {sg(b['mean'])} & {pv(b['p'])} & {sg(r['mean'])} & {pv(r['p'])} & "
                f"{sg(t['mean'])} & {pv(t['p'])} \\\\")
out["T4"]="\n".join(rows)

# T5: parameter matched
rows=[]
for wg,ws in [(16,32),(32,64)]:
    q=paired(acc(ws,"static"),acc(wg,"gap"))
    rows.append(f"\\texttt{{gap}} @ w{wg} ({par(wg,'gap')/1e6:.2f}M) vs \\texttt{{static}} @ w{ws} "
                f"({par(ws,'static')/1e6:.2f}M) & {f(acc(wg,'gap').mean())} & "
                f"{f(acc(ws,'static').mean())} & {sg(q['mean'])} & "
                f"[{sg(q['lo'])}, {sg(q['hi'])}] & {pv(q['p'])} \\\\")
out["T5"]="\n".join(rows)

# T6: entropy
rows=[]
for a in ["uniform","gap","shuffled","frozen_random"]:
    e=np.array([L["z_entropy_norm"] for s in SEEDS for L in R[64][a][s]["routing"]])
    sp=np.array([max(L["z_mean"])-min(L["z_mean"]) for s in SEEDS for L in R[64][a][s]["routing"]])
    rows.append(f"\\texttt{{{a.replace('_',chr(92)+'_')}}} & {f(e.mean(),4)} & {f(e.min(),4)} & "
                f"{f(sp.mean(),4)} & {f(sp.max(),4)} & {len(e)} \\\\")
out["T6"]="\n".join(rows)

for k,v in out.items():
    open(f"tab_{k}.tex","w").write(v+"\n")
    print(f"tab_{k}.tex  ({len(v.splitlines())} rows)")
