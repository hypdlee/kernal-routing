# Stage 1 gates

## COMPLETE (evidence recorded 2026-09-10)

- [x] G1 scipy installed
  EVIDENCE: analyze.py ran to completion, no ImportError.

- [x] G2 grid complete, 24/24 cells
  EVIDENCE: check_grid.py -> "24/24 cells present", no MISSING line.

- [x] G3 grid uniformly configured
  EVIDENCE: check_grid.py -> "AUDIT PASSED"; epochs=150 batch_size=128
  lr=0.1 weight_decay=0.0005 warmup=5 num_kernels=4 scope=all
  temperature=1.0 identical across all 24 runs.

- [x] G4 analysis produced a verdict
  EVIDENCE: uniform vs gap, mean diff -0.032pp, TOST p=0.0033 -> EQUIVALENT.
  frozen_random vs gap, +0.097pp, TOST p=0.0089 -> EQUIVALENT.
  shuffled vs gap, -0.153pp, TOST p=0.0619 -> INCONCLUSIVE.

- [x] G5 verdict read against the pre-registration
  EVIDENCE: decision table row 2, "not significant + TOST p<0.05 ->
  routing is worth less than 0.5pp, write the null". t-test p=0.7752,
  TOST p=0.0033. Row applies.

- [x] G6 routing entropy recorded for all four arms
  EVIDENCE: uniform 1.0000, gap 0.9885 (min 0.9289), shuffled 0.9996,
  frozen_random 0.9971. 96 layer-observations per arm.

- [x] G7 deviations logged
  EVIDENCE: none required; the run matched the pre-registration exactly.

Ledger: 7 of 7 checked.

---

# Stage 1b gates (open)

The Stage 1 grid has no static reference, so it can say routing does not
matter but cannot say what the kernel bank does. This closes that.

- [ ] S1 static arm complete, 6/6 seeds at --scope none
  CHECK: `python check_grid.py --dir results --tag stage1b --routers gap --seeds 0 1 2 3 4 5`
  EXPECT: 6/6 cells present
  EVIDENCE: pending

- [ ] S2 static arm matches the Stage 1 recipe apart from scope
  CHECK: same command
  EXPECT: epochs=150 batch_size=128 lr=0.1 warmup=5, AUDIT PASSED
  EVIDENCE: pending

- [ ] S3 static parameter count is 11.22M
  CHECK: read params.total in any stage1b JSON
  EXPECT: 11220132
  WHY: confirms no dynamic layer leaked in. If it reads 44M, --scope none
  did not take effect and the arm is void.
  EVIDENCE: pending

- [ ] S4 comparison against all four Stage 1 arms
  CHECK: `python compare_static.py`
  EXPECT: a paired difference and CI for each of the four arms vs static
  EVIDENCE: pending

- [ ] S5 the re-parameterisation reading is stated explicitly
  CHECK: manual
  EXPECT: the write-up says whether uniform beats static, and names the
  mechanism as linear over-parameterisation rather than capacity, since
  uniform's effective parameter count is 11.22M not 44.18M
  EVIDENCE: pending

---

# Stage 1c gates (optional, decide deliberately)

- [ ] C1 shuffled resolved
  Currently TOST p=0.0619, just outside. Projected to clear 0.05 at n=7
  (p=0.0464) on the observed sd of 0.459. One extra seed.
  DECISION REQUIRED: extending after an inconclusive pre-registered
  result is legitimate and must be logged in PREREGISTRATION.md with a
  date. Extending after a promising result would be optional stopping.
  This is the former. Log it if you do it.
  EVIDENCE: pending

- [ ] C2 low-capacity replication
  Final train loss is ~0.008 in every arm: the models memorise the
  training set completely. The null may be an artifact of the
  overparameterised regime. Re-run uniform and gap at width 32 or K=2 to
  check the null survives. Two arms, six seeds, cheaper per run.
  EVIDENCE: pending

ABANDON lines go here if a gate becomes impossible, with the reason.
