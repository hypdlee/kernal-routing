"""Read the K sweep at fixed width. Pulls K=4 and static from stage1c."""
from __future__ import annotations
import glob, json, math
import numpy as np
from scipy import stats


def load(width=32):
    arms = {}
    for f in glob.glob("results/*.json"):
        try:
            d = json.load(open(f))
        except Exception:
            continue
        if "router" not in d:
            continue
        c = d["config"]
        if c.get("width", 64) != width:
            continue
        if c.get("scope") == "none":
            arms.setdefault("static", {})[d["seed"]] = d["final_acc"]
        elif d["router"] == "gap":
            arms.setdefault(c.get("num_kernels", 4), {})[d["seed"]] = d["final_acc"]
    return arms


def main(width=32, margin=0.5):
    arms = load(width)
    if "static" not in arms:
        raise SystemExit(f"no static arm at width {width}")
    ks = sorted(k for k in arms if k != "static")
    if not ks:
        raise SystemExit("no gap arms found; run run_ksweep.py first")

    print(f"\nK sweep at width {width}   (static reference, n={len(arms['static'])})\n")
    print(f"  {'K':>3} {'n':>3}  {'mean':>7} {'sd':>6}   {'vs static':>10}  "
          f"{'95% CI':>20}  {'p':>9}")
    base = arms["static"]
    rows = []
    for k in ks:
        seeds = sorted(set(arms[k]) & set(base))
        x = np.array([arms[k][s] for s in seeds])
        y = np.array([base[s] for s in seeds])
        d = x - y; n = len(d)
        if n < 2:
            print(f"  {k:>3} {n:>3}   (need >= 2 paired seeds)"); continue
        t, p = stats.ttest_rel(x, y)
        se = d.std(ddof=1)/math.sqrt(n); crit = stats.t.ppf(0.975, n-1)
        print(f"  {k:>3} {n:>3}  {x.mean():7.3f} {x.std(ddof=1):6.3f}   "
              f"{d.mean():+10.3f}  [{d.mean()-crit*se:+7.3f},{d.mean()+crit*se:+7.3f}]  "
              f"{p:9.5f}")
        rows.append((k, d.mean(), p))

    print(f"\n  static: {np.mean(list(base.values())):.3f}")
    if len(rows) >= 3:
        best = max(rows, key=lambda r: r[1])
        print(f"\n  Largest effect at K={best[0]} ({best[1]:+.3f}pp).")
        effects = [r[1] for r in rows]
        mono = all(effects[i] <= effects[i+1] for i in range(len(effects)-1))
        print("  Effect is monotone in K." if mono else
              "  Effect is NOT monotone in K; report the per-K rows, not a trend.")
    else:
        print(f"\n  Only {len(rows)} values of K; too few to read a trend.")
    print()


if __name__ == "__main__":
    main()
